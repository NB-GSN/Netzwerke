SpionCamp "Tatort Schulnetz" - Mission 2: Java-Labor Caesar
============================================================

Ziel: Programmiert das Caesar-Verfahren und entschluesselt damit die
abgefangenen Nachrichten der Taeter.

1. Oeffnet die Klasse Caesar (Doppelklick) und lest die Kommentare.
2. Stufe BASIS: Methode verschluesseln(char, int) vervollstaendigen.
   Dann Rechtsklick auf Pruefstand -> pruefeBasis() aufrufen.
3. Stufe STANDARD: Methode verschluesselnText(String, int) schreiben.
   Pruefen mit Pruefstand -> pruefeStandard().
4. Stufe EXPERTE: entschluesselnText, bruteForce und zaehleBuchstaben.
   Pruefen mit Pruefstand -> pruefeExperte().

Beweisstuecke: In der Klasse Beweismittel stehen die abgefangenen Nachrichten.
Beim Methodenaufruf koennt ihr als Parameter z. B. Beweismittel.NACHRICHT_2
eintragen.

Fuer alle: Erklaert im Heft in 2 bis 3 Saetzen, was eure Loesung tut und
warum % 26 noetig ist.

Die Missionen und Hilfekarten findet ihr auf der Camp-Seite:
https://nb-gsn.github.io/Netzwerke/spioncamp/
