/**
 * SpionCamp "Tatort Schulnetz" - Pruefstand fuer die Klasse Caesar.
 *
 * Rechtsklick auf diese Klasse und eine der Methoden aufrufen:
 *   pruefeBasis(), pruefeStandard() oder pruefeExperte()
 * Das Ergebnis erscheint im Terminalfenster.
 */
public class Pruefstand
{
    private static int ok;
    private static int fehler;

    /** Prueft die Stufe BASIS: verschluesseln(char, int). */
    public static void pruefeBasis()
    {
        start("BASIS");
        Caesar c = new Caesar();
        pruefe("verschluesseln('H', 3)", "K", "" + c.verschluesseln('H', 3));
        pruefe("verschluesseln('A', 5)", "F", "" + c.verschluesseln('A', 5));
        pruefe("verschluesseln('W', 3)", "Z", "" + c.verschluesseln('W', 3));
        pruefe("verschluesseln('Z', 3)", "C", "" + c.verschluesseln('Z', 3));
        pruefe("verschluesseln('T', 8)", "B", "" + c.verschluesseln('T', 8));
        ende();
    }

    /** Prueft die Stufe STANDARD: verschluesselnText(String, int). */
    public static void pruefeStandard()
    {
        start("STANDARD");
        Caesar c = new Caesar();
        pruefe("verschluesselnText(\"INFORMATIK\", 3)", "LQIRUPDWLN", c.verschluesselnText("INFORMATIK", 3));
        pruefe("verschluesselnText(\"TREFFEN UM ACHT\", 3)", "WUHIIHQ XP DFKW", c.verschluesselnText("TREFFEN UM ACHT", 3));
        pruefe("verschluesselnText(\"XYZ ABC\", 25)", "WXY ZAB", c.verschluesselnText("XYZ ABC", 25));
        pruefe("verschluesselnText(\"\", 5)", "", c.verschluesselnText("", 5));
        ende();
    }

    /** Prueft die Stufe EXPERTE: entschluesselnText und zaehleBuchstaben. bruteForce bitte selbst ausprobieren. */
    public static void pruefeExperte()
    {
        start("EXPERTE");
        Caesar c = new Caesar();
        pruefe("entschluesselnText(\"LQIRUPDWLN\", 3)", "INFORMATIK", c.entschluesselnText("LQIRUPDWLN", 3));
        pruefe("entschluesselnText(\"WUHIIHQ XP DFKW\", 3)", "TREFFEN UM ACHT", c.entschluesselnText("WUHIIHQ XP DFKW", 3));
        int[] a = c.zaehleBuchstaben("ANANAS IM BAZAR");
        pruefe("zaehleBuchstaben(\"ANANAS IM BAZAR\")[0]  (A)", "5", "" + a[0]);
        pruefe("zaehleBuchstaben(\"ANANAS IM BAZAR\")[25] (Z)", "1", "" + a[25]);
        pruefe("zaehleBuchstaben(\"ANANAS IM BAZAR\")[4]  (E)", "0", "" + a[4]);
        ende();
        System.out.println("bruteForce: Ruft die Methode mit Beweismittel.NACHRICHT_2_EXPERTE auf und sucht die sinnvolle Zeile.");
    }

    private static void start(String stufe)
    {
        ok = 0;
        fehler = 0;
        System.out.println("===== Pruefstand Stufe " + stufe + " =====");
    }

    private static void pruefe(String aufruf, String erwartet, String ergebnis)
    {
        if (erwartet.equals(ergebnis)) {
            ok++;
            System.out.println("OK      " + aufruf + " -> \"" + ergebnis + "\"");
        } else {
            fehler++;
            System.out.println("FEHLER  " + aufruf + " -> \"" + ergebnis + "\", erwartet: \"" + erwartet + "\"");
        }
    }

    private static void ende()
    {
        System.out.println("----- " + ok + " von " + (ok + fehler) + " Tests bestanden -----");
        if (fehler == 0) {
            System.out.println("Stufe geschafft! Erklaert jetzt im Heft, was euer Code tut.");
        }
        System.out.println();
    }
}
